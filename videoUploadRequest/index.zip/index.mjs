import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

const s3Client = new S3Client({ region: "us-east-1" });

export const handler = async (event) => {
    const bucketName = "streaming-video-pwa"; // Replace with your bucket name
    const { videoFile } = JSON.parse(event.body);

    const params = {
        Bucket: bucketName,
        Key: `videos/${Date.now()}_${videoFile.name}`, 
        Body: Buffer.from(videoFile.data, "base64"), 
        ACL: "public-read",
        ContentType: videoFile.type,
    };

    try {
        const command = new PutObjectCommand(params);
        await s3Client.send(command);
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Video uploaded successfully!",
                location: `https://${bucketName}.s3.amazonaws.com/${params.Key}`,
            }),
        };
    } catch (error) {
        console.error("Error uploading video:", error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Error uploading video", error: error.message }),
        };
    }
};
